import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object FunTest {
  val tmp1 = "qwe"
  def main(args: Array[String]): Unit = {
    Class.forName("hudi.Metrics")

  }

  def udfTest(input: String): String = {
    // 转换 input -> String
    input + tmp1
  }

}
